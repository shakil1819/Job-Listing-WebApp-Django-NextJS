export const jobTypeOptions = ["Permanent", "Temporary", "Intership"];
export const educationOptions = ["Bachelors", "Masters", "Phd"];
export const industriesOptions = [
  "Business",
  "Information Technology",
  "Banking",
  "Education",
  "Telecommunication",
  "Others",
];
export const experienceOptions = [
  "No Experience",
  "1 Years",
  "2 Years",
  "3 Year+",
];
