import NotFound from "../components/layout/NotFound";

export default function NotFoundPage() {
  return <NotFound />;
}
